# install.ps1
$DTE.ItemOperations.Navigate("https://github.com/Eonasdan/bootstrap-datetimepicker/issues/1128", $DTE.vsNavigateOptions.vsNavigateOptionsNewWindow)
