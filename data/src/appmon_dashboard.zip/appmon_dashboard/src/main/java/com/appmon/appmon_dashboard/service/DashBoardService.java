package com.appmon.appmon_dashboard.service;

import com.appmon.appmon_dashboard.dto.elasticsearch.HitSource;
import org.elasticsearch.action.search.SearchResponse;

import java.util.List;

public interface DashBoardService {
    List<HitSource> getTableRealtime(String startDate, String endDate);
    SearchResponse getGrapeRealtime(String startDate, String endDate);
}
